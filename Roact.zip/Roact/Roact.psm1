# Roact.psm1

# Load WPF Assemblies
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase






function New-RoactElement {
    <#
        .SYNOPSIS
        Creates a new Roact UI element with specified properties.

        .DESCRIPTION
        This function generates a new Roact element based on a predefined set of common elements, such as 'Window', 'Button', and 'TextBox'.
        You can customize each element's properties by passing them in the `$Properties` parameter.

        .PARAMETER Element
        The type of UI element to create. Choose from a set of predefined elements, including:
        - Window
        - Button
        - TextBox
        - Label
        - Panel

        .PARAMETER Properties
        A hashtable of properties to set on the new element. For example, you can set 'Title' for a 'Window' element or 'Content' for a 'Button'.

        .EXAMPLE
        $window = New-RoactElement -Element 'Window' -Properties @{ Title = 'My App'; Width = 300; Height = 200 }

        .EXAMPLE
        $button = New-RoactElement -Element 'Button' -Properties @{ Content = 'Click Me'; Width = 100; Height = 40 }
    #>

    # [cmdletBinding(DefaultParameterSetName = 'All')]

    param (
        # The Element Selected
        [Parameter(Mandatory = $true)]
        [ValidateSet('Window', 'Button')]
        [string]$Element,

        [Parameter(Mandatory = $false)]
        [hashtable]$Properties = @{}
    )

    switch ($Element) {
        'Window' {
            # Create a new window
            $window = New-Object System.Windows.Window
            $canvas = New-Object System.Windows.Controls.Canvas  # Use Canvas for flexible positioning
            $window.Content = $canvas  # Set the Canvas as the window's content

            # Set properties from the hashtable
            $window.Title = $Properties.Title
            $window.Width = $Properties.Width
            $window.Height = $Properties.Height
            
            # Assign the window to the global variable
            $global:RoactWindow = $window
            
            return $window
        }
        'Button' {
            $button = New-Object System.Windows.Controls.Button
            $button.Content = $Properties.Content
            $button.Width = $Properties.Width
            $button.Height = $Properties.Height
            
            # Ensure X and Y properties are provided and are valid numbers
            if ($Properties.X -is [int] -or $Properties.X -is [double]) {
                $button.SetValue([System.Windows.Controls.Canvas]::LeftProperty, [double]$Properties.X)  # Set X position
            } else {
                throw "X position must be a valid number."
            }
            
            if ($Properties.Y -is [int] -or $Properties.Y -is [double]) {
                $button.SetValue([System.Windows.Controls.Canvas]::TopProperty, [double]$Properties.Y)   # Set Y position
            } else {
                throw "Y position must be a valid number."
            }
            
            return $button
        }
        default {
            throw "Element type '$Element' is not supported."
        }
    }
}

function Mount-RoactElement {
    param (
        [object]$Element
    )

    # Assuming you have a global variable for the main window
    $mainWindow = $global:RoactWindow

    if ($Element -is [System.Windows.Window]) {
        # Show the window
        $Element.ShowDialog() | Out-Null
    }
    elseif ($Element -is [System.Windows.Controls.Button]) {
        # Check if the main window's content is a Canvas before adding elements
        if ($mainWindow.Content -is [System.Windows.Controls.Canvas]) {
            # Add the element to the Canvas
            $mainWindow.Content.Children.Add($Element)
        } else {
            throw "Main window's content is not a Canvas or is not set."
        }
    }
    else {
        throw "Element type is not supported for mounting."
    }
}





# Initialize the application
$global:RoactApp = New-Object System.Windows.Application








# Export the functions to make them available
Export-ModuleMember -Function Mount-RoactElement, New-RoactElement
